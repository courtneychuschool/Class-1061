package com.example;

import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;

/**
 * A generic graph representation.
 *
 * @param <V> The type of the vertex.
 */
public class Graph<V> {

    private final Map<V, List<Entry<V, Integer>>> adj;
    public final Map<V, Vertex> vertices;

    public class Vertex {
        private V key;
        public Vertex(V key) {
            this.key = key;
        }
        public V getKey() {
            return key;
        }
    }

    public Graph(List<V> vertexList, Integer[][] edges) {
        this.adj = new HashMap<>();
        this.vertices = new HashMap<>();
        for (V vertex : vertexList) {
            addVertex(vertex);
        }
        for (Integer[] edge : edges) {
            addEdge((V)edge[0], (V)edge[1], edge[2]);
        }
    }

    public void addVertex(V vertex) {
        adj.putIfAbsent(vertex, new ArrayList<>());
        vertices.putIfAbsent(vertex, new Vertex(vertex));
    }

    public void addEdge(V v1, V v2, int weight) {
        addVertex(v1);
        addVertex(v2);
        adj.get(v1).add(new SimpleEntry<>(v2, weight));
        adj.get(v2).add(new SimpleEntry<>(v1, weight)); // For an undirected graph
    }

    public List<V> getNeighbors(V vertex) {
        List<V> neighbors = new ArrayList<>();
        for(Entry<V, Integer> entry : adj.getOrDefault(vertex, Collections.emptyList())) {
            neighbors.add(entry.getKey());
        }
        return neighbors;
    }

    public Set<V> getVertices() {
        return adj.keySet();
    }

    /**
     * Performs a depth-first search starting from a given vertex.
     *
     * @param startVertex The vertex to start the search from.
     * @return A list of vertices in DFS order.
     */
    public List<Vertex> dfs(Vertex startVertex) {
        List<Vertex> result = new ArrayList<>();
        if (!adj.containsKey(startVertex)) {
            return result;
        }

        Set<V> visited = new HashSet<>();
        Stack<V> stack = new Stack<>();

        stack.push(startVertex.getKey());

        while (!stack.isEmpty()) {
            V vertex = stack.pop();
            if (!visited.contains(vertex)) {
                visited.add(vertex);
                result.add(vertices.get(vertex));
                // Add neighbors to the stack in reverse order to visit them in order
                List<V> neighbors = getNeighbors(vertex);
                for (int i = neighbors.size() - 1; i >= 0; i--) {
                    V neighbor = neighbors.get(i);
                    if (!visited.contains(neighbor)) {
                        stack.push(neighbor);
                    }
                }
            }
        }
        return result;
    }

    /**
     * Performs a breadth-first search starting from a given vertex.
     *
     * @param startVertex The vertex to start the search from.
     * @return A list of vertices in BFS order.
     */
    public List<V> bfs() { // Assuming start from the first vertex if not specified
        List<V> result = new ArrayList<>();
        if (adj.isEmpty()) {
            return result;
        }
        V startVertex = adj.keySet().iterator().next();
        Set<V> visited = new HashSet<>();
        Queue<V> queue = new LinkedList<>();

        visited.add(startVertex);
        queue.add(startVertex);
        
        while (!queue.isEmpty()) {
            V vertex = queue.poll();
            result.add(vertex);

            for (V neighbor : getNeighbors(vertex)) {
                if (!visited.contains(neighbor)) {
                    visited.add(neighbor);
                    queue.add(neighbor);
                }
            }
        }
        return result;
    }

    public void printEdges() {
        for (V vertex : adj.keySet()) {
            System.out.print("Vertex " + vertex + " is connected to: ");
            System.out.println(adj.get(vertex));
        }
    }

    // TODO: Implement findMinimumSpanningTree() for Exam 4.
    public void findMinimumSpanningTree() {
        // This method is for Exam 4.
    }
}
