package com.example;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;

public class GraphTest {

	private Graph<Integer> graph;

	@Before
	public void setUp() {
        List<Integer> vertices = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            vertices.add(i);
        }

        // Edges for MST
        Integer[][] edges = {
                {0, 1, 5}, {0, 2, 4},
                {1, 2, 2}, {1, 5, 3},
                {2, 3, 5}, {2, 5, 4},
                {3, 4, 7}, {3, 5, 6},
                {4, 5, 8}
        };
        graph = new Graph<>(vertices, edges);
	}

	@Test
	public void testDfs() {
		System.out.println("\nTesting Depth-First Search starting from vertex 0:");
		List<Graph<Integer>.Vertex> dfsResult = graph.dfs(graph.vertices.get(0));
		List<Integer> dfsKeys = dfsResult.stream().map(v -> v.getKey()).collect(Collectors.toList());
		System.out.println(dfsKeys);
		List<Integer> expected = Arrays.asList(0, 2, 3, 4, 5, 1);
		assertEquals(expected, dfsKeys);
	}

	@Test
	public void testBfs() {
		System.out.println("\nTesting Breadth-First Search starting from vertex 0:");
		List<Integer> bfsResult = graph.bfs();
		System.out.println(bfsResult);
		List<Integer> expected = Arrays.asList(0, 1, 2, 5, 3, 4);
		assertEquals(expected, bfsResult);
	}

	@Test
	public void testFindMinimumSpanningTree() {
		System.out.println("\nOriginal Graph:");
		graph.printEdges();
		Graph<Integer> mst = graph.findMinimumSpanningTree();
		System.out.println("\nMinimum Spanning Tree:");
		mst.printEdges();
	}
}
