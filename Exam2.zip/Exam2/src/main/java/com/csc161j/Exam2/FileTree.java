package com.csc161j.Exam2;

import java.io.File;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Queue;



public class FileTree implements Iterable <FileNode> {

	private FileNode root;
	
	public FileTree(String path) {
		root = new FileNode(path);
		buildTree(root);
	}

	/**
	 * Return a depth first post-order traversal iterator 
	 */
	@Override
	public Iterator<FileNode> iterator() {

		return new DepthFirstIterator();
	}
	
	/**
	 * 	TODO for Exam 2
	 *  Use recursion to build the tree from the directory structure.
	 *  For each of node starting from the root node use listFiles() from File to get 
	 *  the list of files in that directory/folder.
	 *  Create a node for each of the files and add it to a list of child nodes for the node
	 *  Do this recursively for all the nodes.  
	 * 
	 * @param fileNode
	 */
	private void buildTree(FileNode fileNode) {
		File currentFile = fileNode.getFile();
		if (currentFile.isDirectory()) {
			File[] files = currentFile.listFiles();
			if (files != null) { // listFiles() can return null for I/O errors
				for (File file : files) {
					FileNode childNode = new FileNode(file);
					fileNode.getChildNodes().add(childNode);
					buildTree(childNode); // Recursive call
				}
			}
		}
	}
	
	/**
	 * TODO for Exam 2
	 * Iterator that does a post order traversal of the tree.
	 * For post-order traversal use the 2 stack approach outlined here: 
	 * https://www.geeksforgeeks.org/iterative-postorder-traversal/
	 * 
	 * @return 
	 */
	private class DepthFirstIterator implements Iterator<FileNode> {
		
		private Deque<FileNode> postOrderStack;
		
		public DepthFirstIterator() {
			postOrderStack = new ArrayDeque<>();
			if (root == null) {
				return;
			}
			
			// Create a temporary stack for processing
			Deque<FileNode> stack1 = new ArrayDeque<>();
			stack1.push(root);
			
			// Process nodes from stack1 and push them to postOrderStack
			while(!stack1.isEmpty()) {
				FileNode node = stack1.pop();
				postOrderStack.push(node);
				
				// Push children of the popped node onto stack1
				for(FileNode child : node.getChildNodes()) {
					stack1.push(child);
				}
			}

		}

		@Override
		public boolean hasNext() {
			return !postOrderStack.isEmpty();
		}
		
		@Override
		public FileNode next() {
			return postOrderStack.pop();
		}
	}
	
	/**
	 *  Returns an iterator that does a breadth first traversal of the tree using a queue.
	 * 
	 * @return
	 */
	public Iterator<FileNode> breadthFirstIterator() {
		
		return new BreadthFirstIterator();

	}	
	
	/** 
	 * TODO for Exam 2
	 * Iterator that does a breadth first traversal of the tree using a queue.
	 * 
	 */
	private class BreadthFirstIterator implements Iterator<FileNode> {
		
		private Queue<FileNode> queue;
		
		public BreadthFirstIterator() {
			queue = new LinkedList<>(); // LinkedList implements the Queue interface
			if (root != null) {
				queue.add(root);
			}
		}
		
		@Override
		public boolean hasNext() {
			return !queue.isEmpty();
		}

		@Override
		public FileNode next() {
			FileNode currentNode = queue.poll(); // Retrieves and removes the head of the queue
			if (currentNode != null) {
				// Add all children of the current node to the end of the queue
				queue.addAll(currentNode.getChildNodes());
			}
			return currentNode;
		}
		
	}
}
